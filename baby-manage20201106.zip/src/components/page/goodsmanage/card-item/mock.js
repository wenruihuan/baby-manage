export const tableData1 = [
    {
        id: 1,
        name: '1000元会员卡',
        price: '1000',
        tip: '赠送￥200.00',
        img: 'https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png',
        expire_day: '365天',
        is_online: '1',
        sort: 1,
        sell_amount: 100,
    },
    {
        id: 2,
        name: '1000元会员卡',
        price: '1000',
        tip: '赠送￥200.00',
        img: 'https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png',
        expire_day: '365天',
        is_online: '1',
        sort: 1,
        sell_amount: 100,
    },
    {
        id: 3,
        name: '1000元会员卡',
        price: '1000',
        tip: '赠送￥200.00',
        img: 'https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png',
        expire_day: '365天',
        is_online: '1',
        sort: 1,
        sell_amount: 100,
    },
    {
        id: 4,
        name: '1000元会员卡',
        price: '1000',
        tip: '赠送￥200.00',
        img: 'https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png',
        expire_day: '365天',
        is_online: '1',
        sort: 1,
        sell_amount: 100,
    }
];

export const serviceList = [
    {
        id: 1,
        img: 'https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png',
        name: '服务名称服务名称',
        price: '99.00',
        kind_id: '1',
        kind_name: '分类一',
        create_time: '2020-08-29 15:34:23'
    },
    {
        id: 2,
        img: 'https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png',
        name: '服务名称服务名称2',
        price: '99.00',
        kind_id: '1',
        kind_name: '分类一',
        create_time: '2020-08-29 15:34:23'
    },
    {
        id: 3,
        img: 'https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png',
        name: '服务名称服务名称3',
        price: '99.00',
        kind_id: '1',
        kind_name: '分类一',
        create_time: '2020-08-29 15:34:23'
    },
    {
        id: 4,
        img: 'https://www.baidu.com/img/PCtm_d9c8750bed0b3c7d089fa7d55720d6cf.png',
        name: '服务名称服务名称4',
        price: '99.00',
        kind_id: '1',
        kind_name: '分类一',
        create_time: '2020-08-29 15:34:23'
    }
];

export const quanlityList = [
    {
        id: 1,
        content: 'dfsdfas法撒旦',
        rule: '发噶山豆根是fdsgf',
        expire_time: '2020-12-31'
    },
    {
        id: 2,
        content: 'dfsdfas法撒旦',
        rule: '发噶山豆根是fdsgf',
        expire_time: '2020-12-31'
    },
    {
        id: 3,
        content: 'dfsdfas法撒旦',
        rule: '发噶山豆根是fdsgf',
        expire_time: '2020-12-31'
    },
    {
        id: 4,
        content: 'dfsdfas法撒旦',
        rule: '发噶山豆根是fdsgf',
        expire_time: '2020-12-31'
    },
    {
        id: 5,
        content: 'dfsdfas法撒旦',
        rule: '发噶山豆根是fdsgf',
        expire_time: '2020-12-31'
    },
    {
        id: 6,
        content: 'dfsdfas法撒旦',
        rule: '发噶山豆根是fdsgf',
        expire_time: '2020-12-31'
    },
    {
        id: 7,
        content: 'dfsdfas法撒旦',
        rule: '发噶山豆根是fdsgf',
        expire_time: '2020-12-31'
    }
];

export const treeData = [{
    id: 1,
    label: '一级 1',
    children: [{
        id: 4,
        label: '二级 1-1',
        children: [{
            id: 9,
            label: '三级 1-1-1'
        }, {
            id: 10,
            label: '三级 1-1-2'
        }]
    }]
}, {
    id: 2,
    label: '一级 2',
    children: [{
        id: 5,
        label: '二级 2-1'
    }, {
        id: 6,
        label: '二级 2-2'
    }]
}, {
    id: 3,
    label: '一级 3',
    children: [{
        id: 7,
        label: '二级 3-1'
    }, {
        id: 8,
        label: '二级 3-2'
    }]
}];

export const ruleData = [
    {
        id: 1,
        hasSelected: '1',
        rule: '发送发射点发射点'
    }
];