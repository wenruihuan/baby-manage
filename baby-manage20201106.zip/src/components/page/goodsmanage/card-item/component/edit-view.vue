<template>
    <div>123</div>
</template>

<script>
export default {
    name: 'edit-view.vue'
};
</script>

<style lang="css" scoped>

</style>
