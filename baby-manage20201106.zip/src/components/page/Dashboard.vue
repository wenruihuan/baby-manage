<template>
    <div class="Dashboard">
        <div class="banner">
            <img src="../../assets/img/banner_pic.png" alt="">
        </div>
        <div class="common-box">
            <div class="title">
                今日数据
            </div>
            <el-row :gutter="20">
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-1">
                            <i class="el-icon-lx-rechargefill grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">实际收款金额</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-1">
                            <i class="el-icon-lx-people grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">成交客户数</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-2">
                            <i class="el-icon-lx-group grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">新增客户数</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-3">
                            <i class="el-icon-lx-edit grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">今日订单数</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
                <el-col :span="12">
                    <schart ref="bar" class="schart" canvasId="bar" :options="options"></schart>
                </el-col>
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-2">
                            <i class="el-icon-lx-group grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">新增会员数</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-3">
                            <i class="el-icon-lx-edit grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">新增开卡充值</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
            </el-row>
        </div>

        <div class="common-box">
            <div class="title">
                今日数据
            </div>
            <el-row :gutter="20">
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-1">
                            <i class="el-icon-lx-rechargefill grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">实际收款金额</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-1">
                            <i class="el-icon-lx-people grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">成交客户数</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-2">
                            <i class="el-icon-lx-group grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">新增客户数</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
                <el-col :span="6">
                    <el-card shadow="hover" :body-style="{padding: '0px'}">
                        <div class="grid-content grid-con-3">
                            <i class="el-icon-lx-edit grid-con-icon"></i>
                            <div class="grid-cont-right">
                                <div class="grid-num">今日订单数</div>
                            </div>
                        </div>
                        <div class="t-data-value">5000.00</div>
                        <div class="y-data-value">昨日：5000.00</div>
                    </el-card>
                </el-col>
            </el-row>
        </div>
    </div>
</template>

<script>
import Schart from 'vue-schart';
import bus from '../common/bus';
export default {
    name: 'dashboard',
    data() {
        return {
            name: localStorage.getItem('ms_username'),
            data: [
                {
                    name: '2018/09/04',
                    value: 1083
                },
                {
                    name: '2018/09/05',
                    value: 941
                },
                {
                    name: '2018/09/06',
                    value: 1139
                },
                {
                    name: '2018/09/07',
                    value: 816
                },
                {
                    name: '2018/09/08',
                    value: 327
                },
                {
                    name: '2018/09/09',
                    value: 228
                },
                {
                    name: '2018/09/10',
                    value: 1065
                }
            ],
            options: {
                type: 'bar',
                title: {
                    text: '图'
                },
                // xRorate: 25,
                labels: ['服务', '卡项', '产品'],
                datasets: [
                    {
                        label: '图',
                        data: [234, 278, 270]
                    }
                ]
            }
        };
    },
    components: {
        Schart
    },
    computed: {
        role() {
            return this.name === 'admin' ? '超级管理员' : '普通用户';
        }
    },
    // created() {
    //     this.handleListener();
    //     this.changeDate();
    // },
    // activated() {
    //     this.handleListener();
    // },
    // deactivated() {
    //     window.removeEventListener('resize', this.renderChart);
    //     bus.$off('collapse', this.handleBus);
    // },
    methods: {
        changeDate() {
            const now = new Date().getTime();
            this.data.forEach((item, index) => {
                const date = new Date(now - (6 - index) * 86400000);
                item.name = `${date.getFullYear()}/${date.getMonth() + 1}/${date.getDate()}`;
            });
        }
        // handleListener() {
        //     bus.$on('collapse', this.handleBus);
        //     // 调用renderChart方法对图表进行重新渲染
        //     window.addEventListener('resize', this.renderChart);
        // },
        // handleBus(msg) {
        //     setTimeout(() => {
        //         this.renderChart();
        //     }, 200);
        // },
        // renderChart() {
        //     this.$refs.bar.renderChart();
        //     this.$refs.line.renderChart();
        // }
    }
};
</script>


<style scoped>
.el-row {
    margin-bottom: 20px;
}

.grid-content {
    display: flex;
    align-items: center;
    height: 50px;
}

.grid-cont-right {
    flex: 1;
    text-align: center;
    font-size: 14px;
    color: #999;
}

.grid-num {
    text-align: left;
    font-size: 16px;
    text-indent: 30px;
}

.grid-con-icon {
    font-size: 30px;
    width: 50px;
    height: 50px;
    text-align: center;
    line-height: 50px;
    color: #fff;
}

.grid-con-1 .grid-con-icon {
    background: rgb(45, 140, 240);
}

.grid-con-1 .grid-num {
    color: rgb(45, 140, 240);
}

.grid-con-2 .grid-con-icon {
    background: rgb(100, 213, 114);
}

.grid-con-2 .grid-num {
    color: rgb(45, 140, 240);
}

.grid-con-3 .grid-con-icon {
    background: rgb(242, 94, 67);
}

.grid-con-3 .grid-num {
    color: rgb(242, 94, 67);
}

.user-info {
    display: flex;
    align-items: center;
    padding-bottom: 20px;
    border-bottom: 2px solid #ccc;
    margin-bottom: 20px;
}

.user-avator {
    width: 120px;
    height: 120px;
    border-radius: 50%;
}

.user-info-cont {
    padding-left: 50px;
    flex: 1;
    font-size: 14px;
    color: #999;
}

.user-info-cont div:first-child {
    font-size: 30px;
    color: #222;
}

.user-info-list {
    font-size: 14px;
    color: #999;
    line-height: 25px;
}

.user-info-list span {
    margin-left: 70px;
}

.mgb20 {
    margin-bottom: 20px;
}

.todo-item {
    font-size: 14px;
}

.todo-item-del {
    text-decoration: line-through;
    color: #999;
}

.schart {
    width: 100%;
    height: 300px;
}

.banner{
    width: 100%;
}
.banner img{
    width: 100%;
}
.common-box .el-row .el-col{
    margin-bottom: 30px;
}
.common-box{
    background: #fff;
    padding: 30px 15px;
}
.common-box .title{
    font-size: 16px;
    color: #333;
    margin-bottom: 30px;
}
.t-data-value{
    text-indent: 80px;
    font-size: 50px;
}
.y-data-value{
    text-indent: 80px;
    font-size: 20px;
    padding-bottom: 20px;
}

</style>
