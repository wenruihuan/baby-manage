<template>
    <div class="activateCard">

    </div>
</template>

<script>
    export default {
        name: 'activateCard'
    };
</script>

<style scoped>

</style>
