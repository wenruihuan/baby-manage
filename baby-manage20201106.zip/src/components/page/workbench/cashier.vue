<template>
    <div class="cashier"></div>
</template>

<script>
    export default {
        name: 'cashier'
    };
</script>

<style scoped>

</style>
