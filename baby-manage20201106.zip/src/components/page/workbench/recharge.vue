<template>
    <div class="recharge">充值</div>
</template>

<script>
    export default {
        name: 'recharge'
    };
</script>

<style scoped>

</style>
